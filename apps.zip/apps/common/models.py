import uuid
from django.db import models
from django.utils import timezone
from .managers import SoftDeleteManager


class TimeStampedUUIDModel(models.Model):
    """Abstract: UUID PK + created/updated timestamps."""
    uuid = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class SoftDeleteModel(models.Model):
    """
    Abstract: soft-delete only.
    - Default manager excludes deleted rows (SoftDeleteManager).
    - Use .objects.deleted() to query deleted rows.
    - delete() performs soft delete. There is NO hard delete.
    """
    deleted_at = models.DateTimeField(null=True, blank=True, db_index=True)

    # Managers
    objects = SoftDeleteManager()
    all_objects = SoftDeleteManager()  # alias if you want consistent access

    class Meta:
        abstract = True

    # Instance helpers
    def soft_delete(self, save=True):
        if self.deleted_at:
            return  # idempotent
        self.deleted_at = timezone.now()
        if save:
            self.save(update_fields=["deleted_at", "updated_at"])

    def restore(self, save=True):
        self.deleted_at = None
        if save:
            self.save(update_fields=["deleted_at", "updated_at"])

    # Override delete() to always soft-delete
    def delete(self, using=None, keep_parents=False):
        self.soft_delete(save=True)


class ActivatableModel(models.Model):
    """Abstract: boolean active flag with helpers."""
    is_active = models.BooleanField(default=True, db_index=True)

    class Meta:
        abstract = True

    def activate(self, save=True):
        self.is_active = True
        if save:
            self.save(update_fields=["is_active", "updated_at"])

    def deactivate(self, save=True):
        self.is_active = False
        if save:
            self.save(update_fields=["is_active", "updated_at"])


class BaseEntity(TimeStampedUUIDModel, SoftDeleteModel, ActivatableModel):
    """Abstract: UUID + timestamps + soft-delete + is_active."""
    class Meta:
        abstract = True
